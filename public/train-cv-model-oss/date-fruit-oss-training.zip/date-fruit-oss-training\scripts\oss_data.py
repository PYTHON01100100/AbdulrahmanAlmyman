"""
Stream image datasets from Alibaba Cloud OSS into tf.data pipelines.

Images are fetched from OSS on demand while training runs, never downloaded
in bulk, so datasets larger than local disk or RAM work.

Expected bucket layout (one folder per class):

    <prefix>/<class_name>/<image file>
    e.g. train/Ajwa/Ajwa001.jpg, test/Rutab/Rutab017.jpg

Uses the OSS Python SDK (oss2), the non-mounted access method described in
PAI's "Use OSS" guide. Credentials come from OSS_ACCESS_KEY_ID /
OSS_ACCESS_KEY_SECRET, or from PAI's RAM-role credential file (see
get_credentials_provider).
"""

import getpass
import json
import os
import random
import sys
import threading
import time
from collections import defaultdict
from pathlib import Path

import oss2
import tensorflow as tf
from oss2.credentials import (Credentials, CredentialsProvider,
                              EnvironmentVariableCredentialsProvider,
                              StaticCredentialsProvider)

IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp")


# --------------------------------------------------------------------------- #
# OSS access
# --------------------------------------------------------------------------- #
DEFAULT_CRED_PATH = "/mnt/.alibabacloud/credentials"   # written by PAI when a RAM role is set


class FileCredentialsProvider(CredentialsProvider):
    """
    Reads a PAI credential file (JSON with AccessKeyId, AccessKeySecret and
    optionally SecurityToken). The file is re-read whenever it changes, so
    temporary STS credentials from a RAM role keep working as they rotate.
    """

    def __init__(self, path):
        self.path = path
        self._mtime = None
        self._creds = None
        self._lock = threading.Lock()

    def get_credentials(self):
        with self._lock:
            mtime = os.path.getmtime(self.path)
            if self._creds is None or mtime != self._mtime:
                with open(self.path) as f:
                    data = json.load(f)
                self._creds = Credentials(data["AccessKeyId"], data["AccessKeySecret"],
                                          data.get("SecurityToken") or "")
                self._mtime = mtime
            return self._creds


def get_credentials_provider(cred_path=None):
    """
    Pick credentials in this order:
      1. OSS_ACCESS_KEY_ID / OSS_ACCESS_KEY_SECRET (/ OSS_SESSION_TOKEN) env variables
      2. A PAI credential file (RAM role), default /mnt/.alibabacloud/credentials
      3. An interactive prompt, when run in a terminal
    """
    if os.environ.get("OSS_ACCESS_KEY_ID") and os.environ.get("OSS_ACCESS_KEY_SECRET"):
        print("OSS credentials: environment variables")
        return EnvironmentVariableCredentialsProvider()
    path = cred_path or DEFAULT_CRED_PATH
    if os.path.isfile(path):
        print(f"OSS credentials: file {path}")
        return FileCredentialsProvider(path)
    if sys.stdin.isatty():
        print("OSS credentials: prompt")
        return StaticCredentialsProvider(getpass.getpass("OSS AccessKey ID: "),
                                         getpass.getpass("OSS AccessKey Secret: "))
    raise RuntimeError(
        "OSS credentials not found. Set OSS_ACCESS_KEY_ID and OSS_ACCESS_KEY_SECRET, "
        f"or attach a RAM role so PAI writes {DEFAULT_CRED_PATH}.")


class OSSReader:
    """Thread-safe OSS client: each worker thread gets its own oss2.Bucket."""

    def __init__(self, bucket_name, endpoint, region, cred_path=None, retries=4):
        self.bucket_name = bucket_name
        self.endpoint = endpoint
        self.region = region
        self.retries = retries
        self._auth = oss2.ProviderAuthV4(get_credentials_provider(cred_path))
        self._local = threading.local()

    @property
    def bucket(self):
        b = getattr(self._local, "bucket", None)
        if b is None:
            b = oss2.Bucket(self._auth, self.endpoint, self.bucket_name,
                            region=self.region, connect_timeout=30)
            self._local.bucket = b
        return b

    def list_objects(self, prefix):
        """Yield (key, size) for every object under prefix."""
        for obj in oss2.ObjectIteratorV2(self.bucket, prefix=prefix):
            if not obj.key.endswith("/"):
                yield obj.key, obj.size

    def read(self, key):
        """Return an object's bytes, retrying transient network errors."""
        for attempt in range(self.retries):
            try:
                return self.bucket.get_object(key).read()
            except oss2.exceptions.NoSuchKey:
                raise
            except (oss2.exceptions.RequestError, oss2.exceptions.ServerError):
                if attempt == self.retries - 1:
                    raise
                time.sleep(0.5 * 2 ** attempt)

    def upload_dir(self, local_dir, prefix):
        """Upload every file in local_dir to oss://bucket/prefix/, keeping structure."""
        local_dir = Path(local_dir)
        prefix = prefix.rstrip("/") + "/"
        count = 0
        for path in sorted(local_dir.rglob("*")):
            if path.is_file():
                key = prefix + path.relative_to(local_dir).as_posix()
                self.bucket.put_object_from_file(key, str(path))
                count += 1
        return count


# --------------------------------------------------------------------------- #
# Manifests: the list of (key, label) pairs, saved locally so big buckets are
# listed only once
# --------------------------------------------------------------------------- #
def build_manifest(reader, prefix, class_names=None, cache_path=None, refresh=False):
    """
    List images under prefix and label them by their class folder.

    class_names: pass the training classes when building the test manifest so
                 labels line up; images in unknown classes are skipped.
    Returns {"class_names": [...], "items": [[key, label], ...]}.
    """
    prefix = prefix.rstrip("/") + "/" if prefix else ""
    if cache_path and Path(cache_path).exists() and not refresh:
        with open(cache_path) as f:
            manifest = json.load(f)
        if class_names is None or manifest["class_names"] == list(class_names):
            print(f"Loaded manifest {cache_path}: {len(manifest['items'])} images")
            return manifest

    t0 = time.time()
    by_class = defaultdict(list)
    for key, size in reader.list_objects(prefix):
        rel = key[len(prefix):]
        parts = rel.split("/")
        if len(parts) != 2 or size == 0 or not rel.lower().endswith(IMAGE_EXTENSIONS):
            continue
        by_class[parts[0]].append(key)

    if not by_class:
        raise FileNotFoundError(
            f"No images found as oss://{reader.bucket_name}/{prefix}<class>/<image>")

    if class_names is None:
        class_names = sorted(by_class)
    else:
        unknown = sorted(set(by_class) - set(class_names))
        if unknown:
            print(f"WARNING: skipping classes not seen in training: {unknown}")

    items = [[key, idx]
             for idx, name in enumerate(class_names)
             for key in sorted(by_class.get(name, []))]
    manifest = {"class_names": list(class_names), "items": items}
    print(f"Listed oss://{reader.bucket_name}/{prefix}: {len(items)} images, "
          f"{len(class_names)} classes in {time.time() - t0:.1f}s")

    if cache_path:
        Path(cache_path).parent.mkdir(parents=True, exist_ok=True)
        with open(cache_path, "w") as f:
            json.dump(manifest, f)
    return manifest


def stratified_split(items, val_fraction, seed):
    """Split [[key, label], ...] into train/val, keeping class proportions."""
    by_label = defaultdict(list)
    for item in items:
        by_label[item[1]].append(item)
    rng = random.Random(seed)
    train, val = [], []
    for label in sorted(by_label):
        group = sorted(by_label[label])
        rng.shuffle(group)
        n_val = max(1, round(len(group) * val_fraction)) if val_fraction > 0 else 0
        val += group[:n_val]
        train += group[n_val:]
    return train, val


def class_counts(items, num_classes):
    counts = [0] * num_classes
    for _, label in items:
        counts[label] += 1
    return counts


# --------------------------------------------------------------------------- #
# tf.data pipeline that streams from OSS
# --------------------------------------------------------------------------- #
def make_dataset(reader, items, image_size, batch_size, shuffle=False, seed=None,
                 parallel_reads=64):
    """
    Build a tf.data.Dataset of (image, label) batches read from OSS on the fly.

    Only the list of keys is held in memory. Each epoch the keys are shuffled
    (if shuffle=True), then up to `parallel_reads` images are downloaded and
    decoded concurrently while the model trains on earlier batches.
    Images are returned as float32 in [0, 255], resized to image_size.
    Unreadable or corrupt images are skipped with a warning.
    """
    keys = [k for k, _ in items]
    labels = [l for _, l in items]
    ds = tf.data.Dataset.from_tensor_slices((keys, labels))
    if shuffle:
        ds = ds.shuffle(len(keys), seed=seed, reshuffle_each_iteration=True)

    def _fetch(key):
        return tf.constant(reader.read(key.numpy().decode("utf-8")))

    def _load(key, label):
        raw = tf.py_function(_fetch, [key], tf.string)
        img = tf.io.decode_image(raw, channels=3, expand_animations=False)
        img.set_shape([None, None, 3])
        img = tf.image.resize(img, image_size)
        return img, label

    ds = ds.map(_load, num_parallel_calls=parallel_reads, deterministic=not shuffle)
    ds = ds.ignore_errors(log_warning=True)
    ds = ds.batch(batch_size)
    return ds.prefetch(tf.data.AUTOTUNE)
