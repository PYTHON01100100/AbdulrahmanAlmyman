# Note: Two Ways to Feed OSS Data to Training — Preload vs. Stream

I trained this project in two rounds, each reading the dataset from the same OSS bucket in a different way. Both work. Which one is better depends on the size of your dataset.

## Round 1: PAI-DSW notebook, preloading the dataset from OSS

The first round ran in a **Jupyter notebook on PAI-DSW** (Data Science Workshop):

- **Instance:** `ecs.c9i.8xlarge` (32 vCPU, 64 GiB), CPU only, because GPUs were sold out.
- **Image:** `modelscope:1.11.0-pytorch2.1.2tensorflow2.14.0-cpu-py310-ubuntu22.04`
- **Model:** a small CNN trained from scratch.

**How the data was loaded:** before training, the notebook **downloaded the whole dataset once** from OSS to the instance's local disk with the OSS Python SDK (`oss2`): 1,658 files (1,156 training, 502 test, about 20 MB) in **2.6 seconds** over the internal endpoint, using 16 parallel downloads. TensorFlow then read the images from local disk, and `.cache()` kept them **in RAM after the first epoch**. During training, nothing was read from OSS at all.

The full working notebook is included as `notebooks/pai_dsw_preload_training.ipynb`.

**Result:** 29 epochs in about **30 seconds** (about **0.9 s per epoch**), with **82.5%** test accuracy.

## Round 2: ECS with Python scripts, streaming from OSS

The second round ran **Python scripts on an ECS instance** (32 vCPU, CPU only), started with `uv run`:

- **Model:** EfficientNetB0 with transfer learning plus fine-tuning.

**How the data was loaded:** the scripts listed the bucket once (file names only), then **streamed every image from OSS during every epoch**: 64 parallel requests, decoded in memory, used, and discarded. **No images were ever stored on the instance.**

**Result:** 20 epochs in about **2.1 minutes**, with images streamed at about **250 images/s**, and **91.4%** test accuracy.

## Comparison

| | Round 1: Preload | Round 2: Stream |
|---|---|---|
| Where | PAI-DSW notebook | ECS + Python scripts (`uv run`) |
| Data path | OSS → local disk (once) → RAM cache | OSS → memory, every epoch |
| Local copy of the data | Yes (disk + RAM) | None |
| Requests to OSS | Once per file | Once per file **per epoch** |
| Epoch speed | Fastest after the first epoch | Limited by network and CPU |
| Dataset size limit | Must fit on disk (and in RAM for caching) | Practically none |
| Model used | Small CNN | EfficientNetB0 (transfer learning) |
| Test accuracy | 82.5% | 91.4% |

> **The accuracy gap comes from the model, not from how the data was loaded.** Round 2 used a much stronger pretrained model. Preloading and streaming feed the model exactly the same images, so either method gives the same accuracy with the same model.

## Which to use

**Preload when the dataset is small**, fitting comfortably on the instance's disk and ideally in RAM. This was the better choice for this 20 MB date dataset:

- After the first epoch, every image comes from memory, so epochs are as fast as the CPU allows.
- Each file is fetched from OSS only once, so there are fewer requests and the setup is simpler.
- Rerunning or tuning the model doesn't touch OSS again.

**Stream when the dataset is large**, bigger than the instance's disk or RAM, or when you don't want copies of the data on compute machines:

- It works for any dataset size, because only the current batches are in memory.
- Training starts immediately, without waiting for a full download.
- The data stays in one place (OSS). Instances can be replaced without moving anything.
- The cost is one OSS request per file per epoch. Use the **internal endpoint** in the same region so the traffic is fast and free.

**For very large datasets (for example 5 TB of images and audio)**, streaming is the only practical option, but stream **large shards** (TFRecord or WebDataset), not millions of individual files, and train on **GPU instances**. See "Scaling to terabytes" in the main guide.

## Rule of thumb

| Dataset size | Approach |
|---|---|
| Fits easily on disk and in RAM (MBs to a few GB) | **Preload** once, cache in memory |
| Larger than RAM, but fits on disk | Preload to disk, or stream (both work) |
| Larger than disk (hundreds of GB to TBs) | **Stream** from OSS, packed into shards, on GPU instances |
