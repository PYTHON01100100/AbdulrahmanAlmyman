# /// script
# requires-python = ">=3.10,<3.12"
# dependencies = [
#     "tensorflow-cpu==2.14.0",
#     "numpy<2",
#     "oss2>=2.18",
#     "scikit-learn<1.6",
#     "matplotlib<3.10",
# ]
# ///
"""
Train an image classifier on a dataset stored in Alibaba Cloud OSS,
streaming images from the bucket during training (no bulk download).

Bucket layout:  <train-prefix>/<class>/<image>  and  <test-prefix>/<class>/<image>

Example:
    export OSS_ACCESS_KEY_ID=...
    export OSS_ACCESS_KEY_SECRET=...
    uv run train.py --bucket your-bucket-name --model effnet --epochs 15
"""

import os

os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "1")   # oneDNN / Intel AMX kernels
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")    # hide TF info logs

import argparse
import json
import time
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from common import add_oss_args, configure_cpu, evaluate_and_report
from oss_data import OSSReader, build_manifest, class_counts, make_dataset, stratified_split


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    add_oss_args(p)
    d = p.add_argument_group("data")
    d.add_argument("--train-prefix", default="train/")
    d.add_argument("--test-prefix", default="test/", help="set to '' to skip testing")
    d.add_argument("--val-split", type=float, default=0.15,
                   help="fraction of training images held out for validation")
    t = p.add_argument_group("training")
    t.add_argument("--model", choices=["cnn", "effnet"], default="effnet",
                   help="cnn: small CNN from scratch; effnet: pretrained EfficientNetB0")
    t.add_argument("--image-size", type=int, default=None,
                   help="square input size (default 250 for cnn, 224 for effnet)")
    t.add_argument("--batch-size", type=int, default=64)
    t.add_argument("--epochs", type=int, default=30, help="maximum; early stopping may end sooner")
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--patience", type=int, default=6, help="early-stopping patience (epochs)")
    t.add_argument("--fine-tune-epochs", type=int, default=0,
                   help="effnet only: extra epochs with the backbone unfrozen at lr/100")
    t.add_argument("--effnet-weights", default="imagenet",
                   help="'imagenet', a local .h5 weights file, or 'none'")
    t.add_argument("--no-bf16", action="store_true", help="force float32")
    t.add_argument("--seed", type=int, default=123)
    o = p.add_argument_group("output")
    o.add_argument("--output-dir", default="/root/outputs")
    o.add_argument("--run-name", default=time.strftime("run-%Y%m%d-%H%M%S"))
    o.add_argument("--upload-prefix", default="runs/",
                   help="results are uploaded to oss://<bucket>/<upload-prefix><run-name>/")
    o.add_argument("--no-upload", action="store_true")
    return p.parse_args()


def build_model(kind, image_size, num_classes, effnet_weights):
    # Augmentation stays in float32: the rotate/zoom ops don't support bfloat16
    augmentation = keras.Sequential([
        layers.RandomFlip("horizontal_and_vertical", dtype="float32"),
        layers.RandomRotation(0.1, dtype="float32"),
        layers.RandomZoom(0.1, dtype="float32"),
    ], name="augmentation")
    inputs = keras.Input(shape=(image_size, image_size, 3))
    x = augmentation(inputs)
    backbone = None

    if kind == "cnn":
        x = layers.Rescaling(1.0 / 255)(x)
        for filters in (16, 32, 64):
            x = layers.Conv2D(filters, 3, padding="same", activation="relu")(x)
            x = layers.MaxPooling2D()(x)
        x = layers.Flatten()(x)
        x = layers.Dropout(0.3)(x)
        x = layers.Dense(128, activation="relu")(x)
    else:
        weights = None if effnet_weights.lower() == "none" else effnet_weights
        backbone = keras.applications.EfficientNetB0(
            include_top=False, weights=weights, input_shape=(image_size, image_size, 3))
        backbone.trainable = False
        x = backbone(x, training=False)          # expects pixels in [0, 255]
        x = layers.GlobalAveragePooling2D()(x)
        x = layers.Dropout(0.3)(x)

    # float32 output keeps the loss numerically stable under bfloat16
    outputs = layers.Dense(num_classes, dtype="float32", name="logits")(x)
    return keras.Model(inputs, outputs, name=f"date_fruit_{kind}"), backbone


class EpochStats(keras.callbacks.Callback):
    def __init__(self, n_train):
        super().__init__()
        self.n_train = n_train

    def on_epoch_begin(self, epoch, logs=None):
        self.t0 = time.time()

    def on_epoch_end(self, epoch, logs=None):
        dt = time.time() - self.t0
        logs["epoch_time_s"] = dt
        logs["images_per_s"] = self.n_train / dt


def compile_model(model, lr):
    model.compile(optimizer=keras.optimizers.Adam(lr),
                  loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                  metrics=["accuracy"])


class KeepBestWeights(keras.callbacks.Callback):
    """Remember the weights of the epoch with the best validation accuracy (in memory)."""

    def __init__(self):
        super().__init__()
        self.best = -1.0
        self.weights = None

    def on_epoch_end(self, epoch, logs=None):
        if logs.get("val_accuracy", -1) > self.best:
            self.best = logs["val_accuracy"]
            self.weights = self.model.get_weights()

    def restore(self):
        if self.weights is not None:
            self.model.set_weights(self.weights)
            print(f"Restored best epoch weights (val_accuracy {self.best:.4f})")


def fit(model, train_ds, val_ds, epochs, n_train, out_dir, patience, stage, initial_epoch=0):
    # Keras 2.14 callbacks need string paths, hence str(...)
    keep_best = KeepBestWeights()
    callbacks = [
        EpochStats(n_train),
        keep_best,
        keras.callbacks.EarlyStopping(monitor="val_loss", patience=patience),
        keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                          patience=max(2, patience // 2), min_lr=1e-6),
        keras.callbacks.CSVLogger(str(out_dir / f"training_log_{stage}.csv")),
        keras.callbacks.TensorBoard(log_dir=str(out_dir / "logs" / stage)),
    ]
    history = model.fit(train_ds, validation_data=val_ds, epochs=initial_epoch + epochs,
                        initial_epoch=initial_epoch, callbacks=callbacks, verbose=2)
    keep_best.restore()
    return history.history


def copy_trainable_flags(src, dst):
    """Match trainable flags layer by layer so get_weights() order lines up."""
    dst.trainable = src.trainable
    for a, b in zip(getattr(src, "layers", []), getattr(dst, "layers", [])):
        copy_trainable_flags(a, b)


def export_float32(model, kind, image_size, num_classes):
    """
    Rebuild the model in float32 and copy the trained weights into it.
    Training runs in bfloat16 for speed, but TF 2.14 can't reload some bfloat16
    variables (EfficientNet's input normalization) from a saved model, and a
    float32 model also runs on CPUs without AMX.
    """
    weights = [w.astype(np.float32) if w.dtype.name == "bfloat16" else w
               for w in model.get_weights()]
    previous = keras.mixed_precision.global_policy()
    keras.mixed_precision.set_global_policy("float32")
    try:
        model32, _ = build_model(kind, image_size, num_classes, effnet_weights="none")
    finally:
        keras.mixed_precision.set_global_policy(previous)
    copy_trainable_flags(model, model32)
    model32.set_weights(weights)
    return model32


def plot_history(histories, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    h = {k: sum((hist.get(k, []) for hist in histories), []) for k in
         ("accuracy", "val_accuracy", "loss", "val_loss")}
    epochs = range(1, len(h["loss"]) + 1)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(14, 5))
    a1.plot(epochs, h["accuracy"], label="Training accuracy")
    a1.plot(epochs, h["val_accuracy"], label="Validation accuracy")
    a1.set_title("Accuracy"); a1.set_xlabel("Epoch"); a1.legend(loc="lower right")
    a2.plot(epochs, h["loss"], label="Training loss")
    a2.plot(epochs, h["val_loss"], label="Validation loss")
    a2.set_title("Loss"); a2.set_xlabel("Epoch"); a2.legend(loc="upper right")
    if len(histories) > 1:
        for ax in (a1, a2):
            ax.axvline(len(histories[0]["loss"]) + 0.5, color="gray", ls="--", lw=1)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def main():
    args = parse_args()
    image_size = args.image_size or (250 if args.model == "cnn" else 224)
    out_dir = Path(args.output_dir) / args.run_name
    out_dir.mkdir(parents=True, exist_ok=True)
    tf.keras.utils.set_random_seed(args.seed)
    policy = configure_cpu(use_bf16=not args.no_bf16)

    # ---- Data: list the bucket once, then stream images during training ----
    reader = OSSReader(args.bucket, args.endpoint, args.region, cred_path=args.cred_path)
    manifest_dir = Path(args.output_dir) / "manifests" / args.bucket
    train_manifest = build_manifest(
        reader, args.train_prefix, cache_path=manifest_dir / "train.json",
        refresh=args.refresh_manifest)
    class_names = train_manifest["class_names"]
    num_classes = len(class_names)
    train_items, val_items = stratified_split(train_manifest["items"], args.val_split, args.seed)

    print(f"Classes ({num_classes}): {class_names}")
    print(f"Train: {len(train_items)}  Validation: {len(val_items)}")
    print("Train images per class:", dict(zip(class_names, class_counts(train_items, num_classes))))

    common = dict(image_size=(image_size, image_size), batch_size=args.batch_size,
                  parallel_reads=args.parallel_reads)
    train_ds = make_dataset(reader, train_items, shuffle=True, seed=args.seed, **common)
    val_ds = make_dataset(reader, val_items, **common)

    # ---- Model ----
    model, backbone = build_model(args.model, image_size, num_classes, args.effnet_weights)
    compile_model(model, args.lr)
    model.summary(print_fn=lambda s: print(s), expand_nested=False)

    # ---- Train ----
    t0 = time.time()
    histories = [fit(model, train_ds, val_ds, args.epochs, len(train_items), out_dir,
                     args.patience, stage="head" if backbone else "main")]
    if backbone is not None and args.fine_tune_epochs > 0:
        print(f"\nFine-tuning the EfficientNet backbone for up to {args.fine_tune_epochs} epochs")
        backbone.trainable = True
        for layer in backbone.layers:              # BatchNorm stays frozen when fine-tuning
            if isinstance(layer, layers.BatchNormalization):
                layer.trainable = False
        compile_model(model, args.lr / 100)
        histories.append(fit(model, train_ds, val_ds, args.fine_tune_epochs, len(train_items),
                             out_dir, args.patience, stage="finetune",
                             initial_epoch=len(histories[0]["loss"])))
    train_minutes = (time.time() - t0) / 60

    speeds = [s for h in histories for s in h["images_per_s"]]
    print(f"\nTraining took {train_minutes:.1f} min, "
          f"median {np.median(speeds):.0f} images/s streamed from OSS")
    plot_history(histories, out_dir / "training_curves.png")

    # ---- Save ----
    export_float32(model, args.model, image_size, num_classes).save(str(out_dir / "model.keras"))
    with open(out_dir / "class_names.json", "w") as f:
        json.dump(class_names, f)

    # ---- Test ----
    results = {}
    if args.test_prefix:
        test_manifest = build_manifest(
            reader, args.test_prefix, class_names=class_names,
            cache_path=manifest_dir / "test.json", refresh=args.refresh_manifest)
        test_ds = make_dataset(reader, test_manifest["items"], **common)
        results = evaluate_and_report(model, test_ds, class_names, str(out_dir))

    summary = {
        "run_name": args.run_name, "model": args.model, "image_size": image_size,
        "precision": policy, "vcpus": os.cpu_count(),
        "train_images": len(train_items), "val_images": len(val_items),
        "epochs_trained": sum(len(h["loss"]) for h in histories),
        "best_val_accuracy": float(max(a for h in histories for a in h["val_accuracy"])),
        "test_accuracy": results.get("test_accuracy"),
        "train_minutes": round(train_minutes, 2),
        "args": vars(args),
    }
    with open(out_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nOutputs saved to {out_dir}")

    # ---- Back up results to OSS (the system disk is temporary) ----
    if not args.no_upload:
        dest = f"{args.upload_prefix.rstrip('/')}/{args.run_name}/"
        try:
            n = reader.upload_dir(out_dir, dest)
            print(f"Uploaded {n} files to oss://{args.bucket}/{dest}")
        except Exception as e:  # keep local results even if upload fails
            print(f"WARNING: upload to OSS failed ({e}). Results are still in {out_dir}")


if __name__ == "__main__":
    main()
