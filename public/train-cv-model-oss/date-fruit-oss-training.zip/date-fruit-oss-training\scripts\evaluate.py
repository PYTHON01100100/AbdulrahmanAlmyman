# /// script
# requires-python = ">=3.10,<3.12"
# dependencies = [
#     "tensorflow-cpu==2.14.0",
#     "numpy<2",
#     "oss2>=2.18",
#     "scikit-learn<1.6",
#     "matplotlib<3.10",
# ]
# ///
"""
Evaluate a trained model on a test set in OSS (streamed, not downloaded),
or classify individual images.

The model can be a local folder/file or an OSS path written by train.py:

    # Evaluate on oss://<bucket>/test/
    uv run evaluate.py --bucket your-bucket-name \
        --model oss://your-bucket-name/runs/run-20261027-180000/

    # Classify specific images (OSS keys or local files)
    uv run evaluate.py --bucket your-bucket-name --model /root/outputs/run-20261027-180000 \
        --predict test/Ajwa/Ajwa048.jpg my_photo.jpg
"""

import os

os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "1")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

import argparse
import json
import tempfile
import time
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow import keras

from common import add_oss_args, configure_cpu, evaluate_and_report
from oss_data import OSSReader, build_manifest, make_dataset


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    add_oss_args(p)
    p.add_argument("--model", required=True,
                   help="run folder or model.keras file, local or oss://bucket/path")
    p.add_argument("--test-prefix", default="test/")
    p.add_argument("--predict", nargs="+", metavar="IMAGE",
                   help="classify these images (local paths or OSS keys) instead of the test set")
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--output-dir", default=None,
                   help="where to save the report (default: a new folder under /root/outputs)")
    p.add_argument("--no-bf16", action="store_true")
    return p.parse_args()


def resolve_model(path, reader):
    """Return local paths (model.keras, class_names.json), downloading from OSS if needed."""
    if path.startswith("oss://"):
        bucket, _, key = path[len("oss://"):].partition("/")
        if bucket != reader.bucket_name:
            raise ValueError(f"Model is in bucket '{bucket}' but --bucket is '{reader.bucket_name}'")
        folder = key if not key.endswith(".keras") else key.rsplit("/", 1)[0] + "/"
        folder = folder.rstrip("/") + "/"
        local = Path(tempfile.mkdtemp(prefix="model-"))
        for name in ("model.keras", "class_names.json"):
            (local / name).write_bytes(reader.read(folder + name))
        print(f"Downloaded model from oss://{bucket}/{folder}")
        return local / "model.keras", local / "class_names.json"

    p = Path(path)
    model_file = p / "model.keras" if p.is_dir() else p
    return model_file, model_file.parent / "class_names.json"


def load_image(src, reader, size):
    data = Path(src).read_bytes() if Path(src).is_file() else reader.read(src)
    img = tf.io.decode_image(data, channels=3, expand_animations=False)
    return tf.image.resize(img, size)


def main():
    args = parse_args()
    configure_cpu(use_bf16=not args.no_bf16)
    reader = OSSReader(args.bucket, args.endpoint, args.region, cred_path=args.cred_path)

    model_file, names_file = resolve_model(args.model, reader)
    model = keras.models.load_model(str(model_file))
    class_names = json.loads(Path(names_file).read_text())
    size = tuple(model.input_shape[1:3])
    print(f"Model: {model.name}, input {size}, classes: {class_names}")

    if args.predict:
        for src in args.predict:
            img = load_image(src, reader, size)
            probs = tf.nn.softmax(model.predict(img[None], verbose=0)[0]).numpy()
            top3 = np.argsort(probs)[::-1][:3]
            ranked = ", ".join(f"{class_names[i]} {probs[i]:.1%}" for i in top3)
            print(f"{src}: {class_names[top3[0]]}  ({ranked})")
        return

    out_dir = Path(args.output_dir or
                   f"/root/outputs/eval-{time.strftime('%Y%m%d-%H%M%S')}")
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = build_manifest(reader, args.test_prefix, class_names=class_names,
                              refresh=True)
    test_ds = make_dataset(reader, manifest["items"], image_size=size,
                           batch_size=args.batch_size, parallel_reads=args.parallel_reads)
    evaluate_and_report(model, test_ds, class_names, str(out_dir))
    print(f"Report saved to {out_dir}")


if __name__ == "__main__":
    main()
