# Uploading a Dataset to Alibaba Cloud OSS with ossutil

This guide shows how to upload a local dataset folder (with `train/` and `test/` subfolders) to an Alibaba Cloud OSS bucket using `ossutil`, including a fix for a common endpoint error.

## Dataset structure

```
dataset/
├── train/
└── test/
```

## 1. Configure ossutil

Open the ossutil config file:

```bash
nano ~/.ossutilconfig
```

Add the following, replacing the keys with your own AccessKey ID and secret:

```ini
[default]
language=EN
accessKeyID = YOUR_ACCESS_KEY_ID
accessKeySecret = YOUR_ACCESS_KEY_SECRET
region = me-central-1
endpoint = oss-me-central-1.aliyuncs.com
```

Save with `Ctrl+O`, `Enter`, then exit with `Ctrl+X`.

> **Note:** `me-central-1` is the Riyadh region. If your bucket is in another region, use that region's ID and endpoint (shown on the bucket's **Overview** page in the OSS console).

> **Never** commit or share this file. It contains your secret key.

## 2. Upload the dataset

From anywhere, upload the whole folder to the bucket:

```bash
ossutil cp -r -u -j 10 /path/to/dataset/ oss://your-bucket-name/dataset/
```

Example from WSL, where the dataset is on the Windows desktop:

```bash
ossutil cp -r -u -j 10 /mnt/c/Users/<username>/Desktop/dataset/ oss://your-bucket-name/dataset/
```

| Flag | Purpose |
|------|---------|
| `-r` | Upload the folder recursively (all files and subfolders) |
| `-u` | Skip files already uploaded and unchanged, so you can rerun the command to resume an interrupted upload |
| `-j 10` | Run 10 parallel upload jobs, which is faster for many small files |

> **Tip (WSL):** reading from `/mnt/c` is slower than the Linux filesystem. For very large datasets, copy the folder to `~/dataset` first and upload from there.

## 3. Verify the upload

List the uploaded folders:

```bash
ossutil ls oss://your-bucket-name/dataset/ -d
```

If the endpoint in your config isn't being picked up, pass it explicitly:

```bash
ossutil ls oss://your-bucket-name/dataset/ -d -e oss-me-central-1.aliyuncs.com
```

You should see `dataset/train/` and `dataset/test/` in the output.

## Troubleshooting: "no such host" error

If you see an error like this:

```
Error: Get "http://your-bucket-name.temp-XXXXXXXXXXXX.oss-me-central-1.oss-accesspoint.aliyuncs.com/...":
dial tcp: lookup ... no such host
```

**Cause:** ossutil is configured with an **access point** endpoint (`*.oss-accesspoint.aliyuncs.com`) instead of the regional endpoint. ossutil puts the bucket name in front of the endpoint, which produces a hostname that doesn't exist.

**Fix:** set the endpoint in `~/.ossutilconfig` to the standard regional endpoint, as in step 1:

```ini
endpoint = oss-me-central-1.aliyuncs.com
```

Then rerun the upload command from step 2.
