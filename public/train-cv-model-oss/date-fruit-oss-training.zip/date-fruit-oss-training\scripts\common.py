"""Shared helpers: command-line OSS options, CPU tuning, and test-set evaluation."""

import json
import os

import numpy as np
import tensorflow as tf
from tensorflow import keras


def add_oss_args(parser):
    g = parser.add_argument_group("OSS")
    g.add_argument("--bucket", required=True, help="OSS bucket name")
    g.add_argument("--region", default="me-central-1")
    g.add_argument("--endpoint", default="https://oss-me-central-1-internal.aliyuncs.com",
                   help="internal endpoint inside Alibaba Cloud; use "
                        "https://oss-me-central-1.aliyuncs.com from outside")
    g.add_argument("--cred-path", default=None,
                   help="PAI credential file (default /mnt/.alibabacloud/credentials); "
                        "used when OSS_ACCESS_KEY_ID/SECRET are not set")
    g.add_argument("--parallel-reads", type=int, default=64,
                   help="images fetched from OSS concurrently")
    g.add_argument("--refresh-manifest", action="store_true",
                   help="re-list the bucket instead of reusing the saved file list")


def configure_cpu(use_bf16=True):
    """Use all cores and, on CPUs with Intel AMX, bfloat16 mixed precision."""
    n_cpus = os.cpu_count()
    tf.config.threading.set_intra_op_parallelism_threads(n_cpus)
    tf.config.threading.set_inter_op_parallelism_threads(2)

    has_amx = False
    try:
        with open("/proc/cpuinfo") as f:
            has_amx = "amx_bf16" in f.read()
    except OSError:
        pass
    if use_bf16 and has_amx:
        keras.mixed_precision.set_global_policy("mixed_bfloat16")

    policy = keras.mixed_precision.global_policy().name
    print(f"TensorFlow {tf.__version__} | vCPUs: {n_cpus} | AMX: {has_amx} | precision: {policy}")
    return policy


def evaluate_and_report(model, test_ds, class_names, out_dir):
    """Evaluate on the test set, print a report, and save metrics and plots."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import classification_report, confusion_matrix

    y_true, y_pred = [], []
    for images, labels in test_ds:
        y_pred.append(np.argmax(model.predict_on_batch(images), axis=1))
        y_true.append(labels.numpy())
    y_true, y_pred = np.concatenate(y_true), np.concatenate(y_pred)
    labels = list(range(len(class_names)))

    accuracy = float(np.mean(y_true == y_pred))
    report_txt = classification_report(y_true, y_pred, labels=labels,
                                       target_names=class_names, digits=3, zero_division=0)
    report = classification_report(y_true, y_pred, labels=labels, target_names=class_names,
                                   output_dict=True, zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=labels)

    print(f"\nTest accuracy: {accuracy:.4f} ({len(y_true)} images)\n")
    print(report_txt)

    fig, ax = plt.subplots(figsize=(1.0 * len(class_names) + 3, 1.0 * len(class_names) + 2))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(labels, class_names, rotation=45, ha="right")
    ax.set_yticks(labels, class_names)
    for i in labels:
        for j in labels:
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title("Confusion matrix (test set)")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "confusion_matrix.png"), dpi=120)
    plt.close(fig)

    with open(os.path.join(out_dir, "test_report.txt"), "w") as f:
        f.write(f"Test accuracy: {accuracy:.4f} ({len(y_true)} images)\n\n{report_txt}")
    results = {"test_accuracy": accuracy, "test_images": int(len(y_true)),
               "per_class": {n: report[n] for n in class_names},
               "confusion_matrix": cm.tolist()}
    with open(os.path.join(out_dir, "test_results.json"), "w") as f:
        json.dump(results, f, indent=2)
    return results
