# Training an Image Classifier on Alibaba Cloud CPUs, Streaming Data from OSS

This guide walks through a complete, working pipeline for training a computer vision model on Alibaba Cloud: upload a dataset to **Object Storage Service (OSS)**, train on an **ECS CPU instance** that streams images straight from OSS (no bulk download), and get the trained model and reports back to your own machine.

The example project classifies **9 types of Saudi dates** (Ajwa, Galaxy, Mejdool, Meneifi, Nabtat Ali, Rutab, Shaishe, Sokari, Sugaey) from photos. The final model reached **91.4% test accuracy in about 2 minutes of training**.

> **Why CPU and not GPU?**
> When I built this project, GPU instances were **sold out** in my region, so I trained on a CPU instance instead. For a dataset of this size (about 1,650 images) a modern CPU is more than enough. For large datasets, such as **5 TB of images and audio**, you should train on an **ECS GPU instance and stream the data from OSS**. See [Scaling to terabytes](#12-scaling-to-terabytes-5-tb-of-images-and-audio) at the end.

> **Two rounds:** I first trained in a **PAI-DSW notebook**, downloading the dataset from OSS once and caching it in memory, which is the better approach for a small dataset like this one. The second round, which this guide follows, **streams the data from OSS** with Python scripts on ECS, the approach that scales to large datasets. [`note.md`](note.md) compares the two.

---

## Contents

1. [Architecture](#1-architecture)
2. [What's in the package](#2-whats-in-the-package)
3. [Prepare the dataset](#3-prepare-the-dataset)
4. [Set up ossutil on your computer](#4-set-up-ossutil-on-your-computer)
5. [Upload the dataset to OSS](#5-upload-the-dataset-to-oss)
6. [Choose a CPU instance](#6-choose-a-cpu-instance)
7. [Put the scripts on the ECS instance](#7-put-the-scripts-on-the-ecs-instance)
8. [Train, streaming from OSS](#8-train-streaming-from-oss)
9. [Results](#9-results)
10. [Evaluate and predict](#10-evaluate-and-predict)
11. [Download the results to your computer](#11-download-the-results-to-your-computer)
12. [Scaling to terabytes: 5 TB of images and audio](#12-scaling-to-terabytes-5-tb-of-images-and-audio)
13. [Clean up](#13-clean-up)
14. [Troubleshooting](#14-troubleshooting)
15. [Script reference](#15-script-reference)

---

## 1. Architecture

```
 Your computer                     Alibaba Cloud (same region)
┌──────────────┐  ossutil cp   ┌──────────────────────────────┐
│ dataset/     │ ────────────► │ OSS bucket                   │
│  train/      │   (upload)    │  train/<class>/<image>       │
│  test/       │               │  test/<class>/<image>        │
└──────────────┘               │  runs/<run-name>/  ◄──────┐  │
       ▲                       └──────────┬─────────────────┼──┘
       │ ossutil cp                       │ stream images   │ upload model,
       │ (download results)               │ (internal       │ plots, reports
       │                                  ▼  endpoint)      │
       │                       ┌──────────────────────────────┐
       └────────────────────── │ ECS CPU instance (c9i)       │
                               │  uv run train.py             │
                               └──────────────────────────────┘
```

- The dataset lives **only in OSS**. The training machine never stores a copy of it.
- During training, images are **streamed** from OSS over the **internal endpoint**, which is fast and free within the same region.
- Results (model, plots, reports) are **uploaded back to OSS**, so nothing is lost when the instance is released.

---

## 2. What's in the package

```
date-fruit-oss-training/
├── README.md            ← this guide
├── note.md              ← preload vs. stream: my two training rounds compared
├── notebooks/
│   └── pai_dsw_preload_training.ipynb  ← round 1: PAI-DSW notebook, data preloaded from OSS
├── scripts/
│   ├── train.py         ← trains the model, streaming from OSS
│   ├── evaluate.py      ← evaluates a saved model / classifies single images
│   ├── oss_data.py      ← OSS access + tf.data streaming pipeline
│   └── common.py        ← shared options, CPU tuning, evaluation report
└── images/
    ├── training_curves.png
    └── confusion_matrix.png
```

The scripts use **TensorFlow 2.14 (CPU)** and the **OSS Python SDK (`oss2`)**. Each runnable script declares its own dependencies, so `uv run` installs everything automatically. There's no `requirements.txt` to manage.

---

## 3. Prepare the dataset

Use one folder per class inside `train/` and `test/`:

```
dataset/
├── train/
│   ├── Ajwa/
│   │   ├── Ajwa001.jpg
│   │   └── ...
│   ├── Galaxy/
│   └── ...            (one folder per class)
└── test/
    ├── Ajwa/
    └── ...
```

The folder names become the class labels. The date dataset has 1,156 training images and 502 test images across 9 classes.

---

## 4. Set up ossutil on your computer

`ossutil` is Alibaba Cloud's command-line tool for OSS. These steps use **WSL (Ubuntu on Windows)**, but any Linux or macOS terminal works the same way.

Open the config file:

```bash
nano ~/.ossutilconfig
```

Add the following, replacing the keys with your own AccessKey ID and secret:

```ini
[default]
language=EN
accessKeyID = YOUR_ACCESS_KEY_ID
accessKeySecret = YOUR_ACCESS_KEY_SECRET
region = me-central-1
endpoint = oss-me-central-1.aliyuncs.com
```

Save with `Ctrl+O`, `Enter`, then exit with `Ctrl+X`.

- `me-central-1` is the **Riyadh** region. If your bucket is elsewhere, use that region's ID and endpoint, shown on the bucket's **Overview** page in the OSS console.
- **Never commit or share this file.** It contains your secret key.

> **Common mistake: "no such host"**
>
> If you see an error like
> `lookup your-bucket-name.temp-XXXX.oss-me-central-1.oss-accesspoint.aliyuncs.com: no such host`,
> your endpoint is set to an **access point** address (`*.oss-accesspoint.aliyuncs.com`) instead of the regional endpoint. ossutil puts the bucket name in front of the endpoint, which produces a hostname that doesn't exist. Set `endpoint = oss-me-central-1.aliyuncs.com` as shown above.

---

## 5. Upload the dataset to OSS

Upload the `train/` and `test/` folders to the **root** of the bucket:

```bash
ossutil cp -r -u -j 10 /mnt/c/Users/<username>/Desktop/dataset/ oss://your-bucket-name/
```

| Flag | Purpose |
|------|---------|
| `-r` | Upload the folder recursively |
| `-u` | Skip files already uploaded and unchanged, so you can rerun the command to resume an interrupted upload |
| `-j 10` | Run 10 parallel upload jobs, which is faster for many small files |

> **WSL tip:** reading from `/mnt/c` is slower than the Linux filesystem. For very large datasets, copy the folder to `~/dataset` first and upload from there.

Verify the upload:

```bash
ossutil ls oss://your-bucket-name/ -d
```

You should see `oss://your-bucket-name/train/` and `oss://your-bucket-name/test/`.

---

## 6. Choose a CPU instance

With GPUs unavailable, the best CPU option is the **c9i** family:

- **Intel AMX:** the newest Xeon CPUs have built-in matrix units (AMX). TensorFlow uses them automatically when training in **bfloat16**, which makes CPU training several times faster. The scripts detect AMX and enable bfloat16 by themselves.
- **Price per core:** c9i was the cheapest per vCPU among the CPU families offered.

| Dataset / model | Instance |
|---|---|
| Small dataset (~1–2k images), testing scripts | `ecs.c9i.4xlarge` (16 vCPU, 32 GiB) |
| This project, with fast fine-tuning | `ecs.c9i.8xlarge` (32 vCPU, 64 GiB) |

This project trained on **32 vCPUs**. Training itself took about 2 minutes, so most of the instance cost is setup time. Whatever you pick, **stop or release the instance when you're done**.

Create the instance in the **same region as your bucket** (Riyadh, `me-central-1`), so it can use the internal OSS endpoint.

---

## 7. Put the scripts on the ECS instance

Copy the four files from `scripts/` into `/root` on the instance, for example with `scp` from your computer:

```bash
scp scripts/*.py root@<ECS-public-IP>:/root/
```

Or use the **Upload File** button in the ECS console's Workbench terminal.

> **The file names must be exactly `train.py`, `evaluate.py`, `oss_data.py`, `common.py` (lowercase).**
> The scripts import each other by name, and Linux file names are case-sensitive. If you see `error: Failed to spawn: train.py`, check the names with `ls /root/*.py`.

Install **uv**, a fast Python package manager:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
source /root/.local/bin/env
```

Optionally, use Alibaba Cloud's PyPI mirror for faster installs:

```bash
export UV_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/
```

Set your OSS credentials. These prompts hide what you type and keep the keys out of your shell history:

```bash
read -rsp "AccessKey ID: " OSS_ACCESS_KEY_ID; echo; export OSS_ACCESS_KEY_ID
read -rsp "AccessKey Secret: " OSS_ACCESS_KEY_SECRET; echo; export OSS_ACCESS_KEY_SECRET
```

> On **PAI** (DSW or DLC) with a RAM role attached, you can skip this step: the scripts also read PAI's credential file at `/mnt/.alibabacloud/credentials`.

---

## 8. Train, streaming from OSS

```bash
cd /root
nohup uv run train.py --bucket your-bucket-name --model effnet --epochs 15 --fine-tune-epochs 5 > train.log 2>&1 &
tail -f train.log
```

- `nohup ... &` keeps training running even if your terminal disconnects. `Ctrl+C` stops `tail`, not the training.
- The first run spends a few minutes installing TensorFlow. Later runs start in seconds.

What each option does:

| Option | Meaning |
|---|---|
| `--bucket` | The OSS bucket containing `train/` and `test/` |
| `--model effnet` | **EfficientNetB0** pretrained on ImageNet (transfer learning). `cnn` trains a small CNN from scratch instead |
| `--epochs 15` | Stage 1: train only the new classifier head, with the backbone frozen |
| `--fine-tune-epochs 5` | Stage 2: unfreeze the backbone and train everything at a 100× lower learning rate |

### How the streaming works

1. **List once.** The script lists every image key under `train/` and `test/` and saves the list as a small JSON *manifest*. No images are saved.
2. **Stream each epoch.** The key list is shuffled and **64 images are fetched from OSS in parallel**. Each one is decoded in memory, resized, batched and fed to the model, then discarded. The next epoch fetches them again, in a new order.
3. **Nothing is stored locally**, so the dataset can be larger than the instance's disk or RAM.

You can confirm it on the instance. No image files exist locally:

```bash
find /root -name "*.jpg" | wc -l     # → 0
```

The training log also shows the streaming speed for every epoch (`images_per_s`).

### What the output looks like

```
TensorFlow 2.14.0 | vCPUs: 32 | AMX: True | precision: mixed_bfloat16
OSS credentials: environment variables
Listed oss://your-bucket-name/train/: 1156 images, 9 classes in 0.2s
Train: 983  Validation: 173
Epoch 1/15
...
Training took 2.1 min, median 250 images/s streamed from OSS
Test accuracy: 0.9143 (502 images)
Outputs saved to /root/outputs/run-20261027-232349
Uploaded 13 files to oss://your-bucket-name/runs/run-20261027-232349/
```

Every run is saved to `/root/outputs/<run-name>/` and **uploaded automatically** to `oss://<bucket>/runs/<run-name>/`.

---

## 9. Results

| | Small CNN from scratch | **EfficientNetB0, transfer learning + fine-tuning** |
|---|---|---|
| Test accuracy | 82.5% | **91.4%** |
| Training time (32 vCPU, bfloat16) | ~0.5 min | **~2.1 min** |

**Training curves.** The dashed line marks the start of fine-tuning, which gives a clear jump. Training and validation stay close, so the model isn't overfitting, and validation loss was still falling at the end. More fine-tuning epochs would likely improve it further.

![Training curves](images/training_curves.png)

**Confusion matrix (test set).** Ajwa and Nabtat Ali were recognized perfectly (100% recall). Most remaining errors involve **Meneifi**, which gets spread across several similar-looking types.

![Confusion matrix](images/confusion_matrix.png)

| Class | Precision | Recall | F1 |
|---|---|---|---|
| Ajwa | 1.000 | 1.000 | 1.000 |
| Galaxy | 0.897 | 0.912 | 0.904 |
| Mejdool | 0.952 | 0.976 | 0.964 |
| Meneifi | 0.847 | 0.714 | 0.775 |
| Nabtat Ali | 0.857 | 1.000 | 0.923 |
| Rutab | 0.976 | 0.932 | 0.953 |
| Shaishe | 0.980 | 0.923 | 0.950 |
| Sokari | 0.882 | 0.938 | 0.909 |
| Sugaey | 0.902 | 0.902 | 0.902 |

**Streaming speed:** about **250 images/s** while training the head and about 93 images/s while fine-tuning the whole network. The drop during fine-tuning shows that the **CPU, not OSS, was the bottleneck**: images arrived faster than the model could use them.

---

## 10. Evaluate and predict

`train.py` already tests the model at the end. Use `evaluate.py` later to recheck a saved run or to classify individual images. The model is loaded straight from OSS:

```bash
# Re-evaluate a saved run on the test set
uv run evaluate.py --bucket your-bucket-name --model oss://your-bucket-name/runs/run-20261027-232349/

# Classify single images (OSS keys or local files)
uv run evaluate.py --bucket your-bucket-name --model oss://your-bucket-name/runs/run-20261027-232349/ \
    --predict test/Ajwa/Ajwa048.jpg my_photo.jpg
```

Example prediction output:

```
test/Ajwa/Ajwa048.jpg: Ajwa  (Ajwa 100.0%, Shaishe 0.0%, Mejdool 0.0%)
```

---

## 11. Download the results to your computer

From your local terminal (the one where `ossutil` is configured), list the runs:

```bash
ossutil ls oss://your-bucket-name/runs/ -d
```

Download one run:

```bash
ossutil cp -r oss://your-bucket-name/runs/run-20261027-232349/ /mnt/c/Users/<username>/Desktop/runs/run-20261027-232349/
```

Or download all runs. `-u` fetches only what's new:

```bash
ossutil cp -r -u oss://your-bucket-name/runs/ /mnt/c/Users/<username>/Desktop/runs/
```

Each run folder contains:

| File | What it is |
|---|---|
| `model.keras` | The trained model, loadable with `keras.models.load_model()` |
| `class_names.json` | Class order matching the model's outputs |
| `training_curves.png`, `confusion_matrix.png` | Plots |
| `test_report.txt`, `test_results.json` | Test accuracy and per-class metrics |
| `summary.json` | All settings and results of the run |
| `training_log_*.csv`, `logs/` | Per-epoch metrics and TensorBoard logs |

---

## 12. Scaling to terabytes: 5 TB of images and audio

The pipeline in this guide is right for small and medium datasets, up to a few hundred thousand files. **For a dataset like 5 TB of images and audio, train on an ECS GPU instance and stream the data from OSS**, with a few changes to how the data is stored and read.

### Why the CPU setup doesn't scale to 5 TB

5 TB of typical photos and audio clips is on the order of **tens of millions of files**.

- **Compute:** at ~250 images/s on 32 CPU cores, 20 million images would take about **22 hours per epoch**, and fine-tuning is ~3× slower still. GPUs are essential at this scale.
- **One request per file:** streaming each file individually means tens of millions of OSS requests per epoch. Per-request latency limits throughput, and request fees add up every epoch.
- **Audio** needs its own decoding and feature extraction (for example, log-mel spectrograms), which is expensive to repeat every epoch.

### The recommended setup

1. **Train on an ECS GPU instance** (or a GPU job in **PAI-DLC** for multi-GPU or multi-node training), in the **same region as the bucket**, reading over the internal endpoint.
2. **Keep the data in OSS and stream it**, exactly as in this guide. Don't copy 5 TB onto instance disks.
3. **Pack the data into shards first.** Preprocess once and pack thousands of samples into large files (**TFRecord** or **WebDataset `.tar`**, about 100 MB–1 GB each). Streaming a few thousand large files sequentially is far faster and cheaper than millions of tiny requests. For audio, store **precomputed features**, so the expensive work isn't repeated every epoch.
4. **Stream the shards** with one of the options from the PAI "Use OSS" documentation:
   - **TensorFlow:** mount the bucket with **ossfs 2.0 or JindoFuse**, read shards with `tf.data.TFRecordDataset`, and shuffle the shard order plus an in-memory shuffle buffer.
   - **PyTorch:** use the **OSS Connector for AI/ML** (`OssIterableDataset`), which is designed for streaming large datasets from OSS.
5. **Checkpoint to OSS regularly**, so a multi-day job resumes after a failure instead of restarting.
6. **Use separate models (or input branches) for audio and images**, since they need different preprocessing and architectures.

> **Note on these scripts and GPUs:** the scripts in this package target CPUs. They install `tensorflow-cpu` and use bfloat16, which relies on Intel AMX. To run them on a GPU instance, change the dependency to the GPU build of TensorFlow and use `mixed_float16` precision. For terabyte-scale data, also switch the input pipeline to sharded reads as described above.

---

## 13. Clean up

- **Stop or release the ECS instance** when training is done. Pay-as-you-go instances keep billing while they run.
- Your dataset and every training run stay safe in OSS.
- If you created AccessKeys just for this project, consider disabling them in the RAM console afterwards.

---

## 14. Troubleshooting

| Problem | Cause and fix |
|---|---|
| `no such host` with `oss-accesspoint` in the address | ossutil's endpoint is set to an access point. Set `endpoint = oss-me-central-1.aliyuncs.com` ([section 4](#4-set-up-ossutil-on-your-computer)) |
| `error: Failed to spawn: train.py` | The script isn't in the current folder, or the names have the wrong case. Run `ls /root/*.py` |
| `No module named 'oss_data'` | `oss_data.py` is missing or misnamed (for example `oss.py`). Rename it |
| `No images found as oss://bucket/train/<class>/<image>` | Wrong folder layout or prefix. If your data is under `dataset/train/`, add `--train-prefix dataset/train/ --test-prefix dataset/test/` |
| Connection errors or timeouts to OSS | The instance isn't in the bucket's region, so the internal endpoint is unreachable. Add `--endpoint https://oss-me-central-1.aliyuncs.com` |
| `AccessDenied` | The AccessKey's RAM user needs read access to the bucket (and write access for the results upload) |
| `OSS credentials not found` | Run the two `read -rsp` lines again. Environment variables only last for the current terminal session |
| Low `images_per_s` during the head stage | Increase `--parallel-reads` (for example 128) |
| EfficientNet weights fail to download | The instance has no internet access. Upload `efficientnetb0_notop.h5` and pass `--effnet-weights /path/to/file.h5` |

---

## 15. Script reference

### `train.py`

| Option | Default | Description |
|---|---|---|
| `--bucket` | (required) | OSS bucket name |
| `--region` | `me-central-1` | Bucket region |
| `--endpoint` | `https://oss-me-central-1-internal.aliyuncs.com` | Use the public endpoint from outside Alibaba Cloud |
| `--train-prefix` / `--test-prefix` | `train/` / `test/` | Folders in the bucket. Use `--test-prefix ""` to skip testing |
| `--model` | `effnet` | `effnet` (EfficientNetB0, pretrained) or `cnn` (small CNN from scratch) |
| `--image-size` | 224 (effnet) / 250 (cnn) | Square input size |
| `--epochs` | 30 | Maximum epochs for stage 1. Early stopping may end it sooner |
| `--fine-tune-epochs` | 0 | EfficientNet only: extra epochs with the backbone unfrozen |
| `--batch-size` | 64 | Images per batch |
| `--val-split` | 0.15 | Share of training images held out for validation |
| `--parallel-reads` | 64 | Images fetched from OSS concurrently |
| `--output-dir` | `/root/outputs` | Local output folder |
| `--upload-prefix` / `--no-upload` | `runs/` | Where results are uploaded in the bucket, or disable uploading |
| `--no-bf16` | off | Force float32 (bfloat16 is used automatically when the CPU has AMX) |

### `evaluate.py`

| Option | Description |
|---|---|
| `--bucket` | OSS bucket name (required) |
| `--model` | Run folder or `model.keras`, local or `oss://bucket/runs/<run-name>/` |
| `--test-prefix` | Test folder in the bucket (default `test/`) |
| `--predict IMAGE ...` | Classify the given images (OSS keys or local files) instead of the test set |

Run `uv run train.py --help` for the full list.

### Technical notes

- **Mixed precision:** training runs in bfloat16 on AMX CPUs. The data augmentation layers stay in float32 (TensorFlow 2.14's rotate and zoom ops don't support bfloat16), and so does the output layer, for numerical stability.
- **Saved model:** the model is exported in **float32**, because TensorFlow 2.14 can't reload EfficientNet's bfloat16 normalization weights from a saved file. A float32 model also runs on any CPU. Expect a fraction of a percent difference between the test accuracy at the end of training and from `evaluate.py`.
- **Validation:** 15% of the training images are held out (stratified by class), so the **test set is used only once**, for the final score.
- **Corrupt files** are skipped during streaming instead of stopping training.
